package com.example.indigoService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndigoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
