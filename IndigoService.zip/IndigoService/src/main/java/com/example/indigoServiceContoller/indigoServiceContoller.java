package com.example.indigoServiceContoller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.indigoServiceModel.Flight;
import com.example.indigoServiceService.indigoServiceService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/flight")
@CrossOrigin
public class indigoServiceContoller {
	
	@Autowired
	private indigoServiceService indigoserviceservice;
	
	@PostMapping("/add")
	public String add(@RequestBody Flight flight) {
		indigoserviceservice.saveFlight(flight);
		return "New Flight is Added!";
	}
	
	@GetMapping("/getflight")
	public List<Flight> getFlight(){
		return indigoserviceservice.getFlight();
	}
	
}
