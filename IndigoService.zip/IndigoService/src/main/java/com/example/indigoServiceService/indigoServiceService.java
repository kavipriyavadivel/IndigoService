package com.example.indigoServiceService;

import java.util.List;

import com.example.indigoServiceModel.Flight;

public interface indigoServiceService {
	public Flight saveFlight(Flight flight);
	public List<Flight> getFlight();
}
