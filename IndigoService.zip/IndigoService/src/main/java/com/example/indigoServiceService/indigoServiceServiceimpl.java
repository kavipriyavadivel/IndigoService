package com.example.indigoServiceService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.indigoServiceModel.Flight;
import com.example.indigoServiceRepository.indigoServiceRepository;

import jakarta.transaction.Transactional;

@Service
public class indigoServiceServiceimpl implements indigoServiceService{
	@Autowired
	private indigoServiceRepository indigoservicerepository;
	
	@Override
	 @Transactional
	public Flight saveFlight(Flight flight) {
		System.out.println("Saving flight: " + flight);
		return indigoservicerepository.save(flight);
	}

	@Override
	public List<Flight> getFlight() {
		// TODO Auto-generated method stub
		return indigoservicerepository.findAll();
	}
	

}
