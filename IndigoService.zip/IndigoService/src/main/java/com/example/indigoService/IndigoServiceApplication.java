package com.example.indigoService;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication(scanBasePackages = {
	    "com.example.indigoServiceContoller", 
	    "com.example.indigoServiceService", 
	    "com.example.indigoServiceRepository",
	    "com.example.indigoServiceModel"
	})
@EntityScan(basePackages = {"com.example.indigoServiceModel"})
@EnableJpaRepositories(basePackages = {"com.example.indigoServiceRepository"}) 
public class IndigoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndigoServiceApplication.class, args);
	}

}
