import React, { useEffect, useState } from 'react';
import './Indigo.css'; // Import the new CSS file for styles

const Indigo = () => {
  const [des, setDes] = useState('');
  const [name, setName] = useState('');
  const [src, setSrc] = useState('');
  const [flight, setFlight] = useState([]);

  const handleClick = (e) => {
    e.preventDefault();
    const flights = { des, name, src };
    console.log(flights);
    fetch("http://localhost:8080/flight/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(flights)
    }).then(() => {
      console.log("New Flight Added!");
    });
  };

  useEffect(() => {
    fetch("http://localhost:8080/flight/getflight")
      .then(res => res.json())
      .then((result) => {
        setFlight(result);
      });
  }, []);

  return (
    <div className="container">
      <form className="flight-form">
        <h1>Indigo Flight Form</h1>
        <label htmlFor='des'>Destination:</label>
        <input
          value={des}
          type='text'
          onChange={(e) => setDes(e.target.value)}
          placeholder="Enter destination"
        />
        <label htmlFor='name'>Name:</label>
        <input
          value={name}
          type='text'
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter name"
        />
        <label htmlFor='src'>Source:</label>
        <input
          value={src}
          type='text'
          onChange={(e) => setSrc(e.target.value)}
          placeholder="Enter source"
        />
        <button onClick={handleClick} className="submit-btn">Submit</button>
      </form>

      <div className="flight-list">
        {flight.map(fli => (
          <div className="flight-card" key={fli.id}>
            <p><strong>Id:</strong> {fli.id}</p>
            <p><strong>Name:</strong> {fli.name}</p>
            <p><strong>Destination:</strong> {fli.des}</p>
            <p><strong>Source:</strong> {fli.src}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Indigo;
